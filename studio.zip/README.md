# Text Utilities

This app is for general use, currently it offers 2 utilities;

## 1- Convert Text to UpperCase
You can write or insert any text you want to convert to uppercase letters and then click the respective button available below the text area.
## 2- Convert Text to LowerCase
You can write or insert any text you want to convert to lowercase letters and then click the respective button available below the text area.
## 3- Delete or Reset
Instead of removing all the text manaually you can do that by clicking the delete button.

Live App:
https://textutiliz.netlify.app/
